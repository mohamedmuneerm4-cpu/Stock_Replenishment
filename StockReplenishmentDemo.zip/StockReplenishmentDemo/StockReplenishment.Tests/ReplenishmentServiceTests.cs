﻿using Microsoft.EntityFrameworkCore;
using NSubstitute;
using NUnit.Framework;
using StockReplenishment.Data;
using StockReplenishment.Models;
using StockReplenishment.Services;

namespace StockReplenishment.Tests;

[TestFixture]
public class ReplenishmentServiceTests
{
    private AppDbContext _db = null!;
    private IValidationQueue _queue = null!;
    private ReplenishmentService _service = null!;

    [SetUp]
    public void Setup()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        _db = new AppDbContext(options);

        _queue = Substitute.For<IValidationQueue>();

        _service = new ReplenishmentService(
            _db,
            _queue);
    }

    [TearDown]
    public void Cleanup()
    {
        _db.Dispose();
    }

    [Test]
    public async Task SubmitRequest_ShouldSetValidationStatusToPending()
    {
        // Arrange
        var request = new ReplenishmentRequest
        {
            StockLocation = "LINE-01",
            Priority = RequestPriority.Normal,
            Status = RequestStatus.Draft,
            ValidationStatus = ValidationStatus.NotStarted,

            Items =
            [
                new ReplenishmentItem
                {
                    ArticleNumber = "ART-001",
                    Description = "Motor",
                    RequestedQuantity = 10
                }
            ]
        };

        _db.ReplenishmentRequests.Add(request);

        await _db.SaveChangesAsync();

        // Act
        await _service.SubmitAsync(request.Id);

        // Assert
        var result = await _db.ReplenishmentRequests
            .FirstAsync(x => x.Id == request.Id);

        Assert.That(
            result.Status,
            Is.EqualTo(RequestStatus.Submitted));

        Assert.That(
            result.ValidationStatus,
            Is.EqualTo(ValidationStatus.Pending));

        Assert.That(
            result.SubmittedAt,
            Is.Not.Null);

        // Check that request was added to background queue
        await _queue.Received(1)
            .EnqueueAsync(request.Id);
    }
}