﻿using StockReplenishment.Models;

namespace StockReplenishment.Services;

public class StockAvailabilityService : IStockAvailabilityService
{
    public async Task<(bool Available, string Message)> CheckAsync(
        ReplenishmentRequest request,
        CancellationToken cancellationToken)
    {
        // Simulate slow external API
        await Task.Delay(
            TimeSpan.FromSeconds(4),
            cancellationToken);

        // Demo rule:
        // <= 100 per item = available
        // > 100 = unavailable

        bool available = request.Items
            .All(x => x.RequestedQuantity <= 100);

        if (available)
        {
            return (
                true,
                "Stock is available for all requested items."
            );
        }

        return (
            false,
            "Stock is not available for one or more requested items."
        );
    }
}