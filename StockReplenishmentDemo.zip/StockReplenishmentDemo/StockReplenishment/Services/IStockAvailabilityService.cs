﻿using StockReplenishment.Models;

namespace StockReplenishment.Services;

public interface IStockAvailabilityService
{
    Task<(bool Available, string Message)> CheckAsync(
        ReplenishmentRequest request,
        CancellationToken cancellationToken);
}