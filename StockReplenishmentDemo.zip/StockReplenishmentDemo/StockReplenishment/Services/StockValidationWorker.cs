﻿using Microsoft.EntityFrameworkCore;
using StockReplenishment.Data;
using StockReplenishment.Models;

namespace StockReplenishment.Services;

public class StockValidationWorker : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IValidationQueue _queue;
    private readonly ILogger<StockValidationWorker> _logger;

    public StockValidationWorker(
        IServiceScopeFactory scopeFactory,
        IValidationQueue queue,
        ILogger<StockValidationWorker> logger)
    {
        _scopeFactory = scopeFactory;
        _queue = queue;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var requestId =
                await _queue.DequeueAsync(stoppingToken);

            try
            {
                using var scope =
                    _scopeFactory.CreateScope();

                var db =
                    scope.ServiceProvider
                        .GetRequiredService<AppDbContext>();

                var stockService =
                    scope.ServiceProvider
                        .GetRequiredService<IStockAvailabilityService>();

                var request =
                    await db.ReplenishmentRequests
                        .Include(x => x.Items)
                        .FirstOrDefaultAsync(
                            x => x.Id == requestId,
                            stoppingToken);

                if (request == null)
                    continue;

                var result =
                    await stockService.CheckAsync(
                        request,
                        stoppingToken);

                request.ValidationStatus =
                    result.Available
                        ? ValidationStatus.Available
                        : ValidationStatus.Unavailable;

                request.ValidationMessage =
                    result.Message;

                await db.SaveChangesAsync(stoppingToken);

                _logger.LogInformation(
                    "Stock validation completed for request {Id}",
                    requestId);
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Stock validation failed for request {Id}",
                    requestId);
            }
        }
    }
}