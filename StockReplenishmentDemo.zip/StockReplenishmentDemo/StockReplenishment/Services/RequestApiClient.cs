﻿using System.Net.Http.Json;
using StockReplenishment.DTOs;
using StockReplenishment.Models;

namespace StockReplenishment.Services;

public class RequestApiClient
{
    private readonly HttpClient _http;

    public RequestApiClient(HttpClient http)
    {
        _http = http;
    }

    public async Task<PagedResult<RequestSummaryDto>> GetRequestsAsync(
        string? status,
        string? priority,
        string? location,
        int page = 1)
    {
        var url =
            $"api/replenishment-requests?page={page}&pageSize=10";

        if (!string.IsNullOrWhiteSpace(status))
            url += $"&status={Uri.EscapeDataString(status)}";

        if (!string.IsNullOrWhiteSpace(priority))
            url += $"&priority={Uri.EscapeDataString(priority)}";

        if (!string.IsNullOrWhiteSpace(location))
            url += $"&location={Uri.EscapeDataString(location)}";

        return await _http.GetFromJsonAsync<
            PagedResult<RequestSummaryDto>>(url)
            ?? new();
    }

    public async Task<RequestDetailDto?> GetAsync(int id)
    {
        return await _http.GetFromJsonAsync<RequestDetailDto>(
            $"api/replenishment-requests/{id}");
    }

    public async Task<RequestDetailDto?> CreateAsync(
        CreateRequestDto dto)
    {
        var response = await _http.PostAsJsonAsync(
            "api/replenishment-requests",
            dto);

        response.EnsureSuccessStatusCode();

        return await response.Content
            .ReadFromJsonAsync<RequestDetailDto>();
    }

    public async Task SubmitAsync(int id)
    {
        var response = await _http.PostAsync(
            $"api/replenishment-requests/{id}/submit",
            null);

        response.EnsureSuccessStatusCode();
    }

    public async Task ApproveAsync(int id)
    {
        var response = await _http.PostAsync(
            $"api/replenishment-requests/{id}/approve",
            null);

        response.EnsureSuccessStatusCode();
    }

    public async Task RejectAsync(
        int id,
        string reason)
    {
        var response = await _http.PostAsJsonAsync(
            $"api/replenishment-requests/{id}/reject",
            new RejectRequestDto
            {
                Reason = reason
            });

        response.EnsureSuccessStatusCode();
    }

    public async Task FulfillAsync(
        int id,
        FulfillRequestDto dto)
    {
        var response = await _http.PostAsJsonAsync(
            $"api/replenishment-requests/{id}/fulfill",
            dto);

        response.EnsureSuccessStatusCode();
    }
}