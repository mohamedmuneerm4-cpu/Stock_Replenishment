﻿namespace StockReplenishment.Services;

public interface IValidationQueue
{
    ValueTask EnqueueAsync(int requestId);

    ValueTask<int> DequeueAsync(
        CancellationToken cancellationToken);
}