﻿using Microsoft.EntityFrameworkCore;
using StockReplenishment.Data;
using StockReplenishment.DTOs;
using StockReplenishment.Models;
using System.ComponentModel.DataAnnotations;


namespace StockReplenishment.Services;

public class ReplenishmentService
{
    private readonly AppDbContext _db;
    private readonly IValidationQueue _queue;

    public ReplenishmentService(
        AppDbContext db,
        IValidationQueue queue)
    {
        _db = db;
        _queue = queue;
    }

    public async Task<RequestDetailDto> CreateAsync(
        CreateRequestDto dto)
    {
        if (dto.Items.Count == 0)
            throw new ValidationException(
                "At least one item is required.");

        var request = new ReplenishmentRequest
        {
            StockLocation = dto.StockLocation.Trim(),
            Priority = dto.Priority,
            Status = RequestStatus.Draft,
            CreatedAt = DateTime.UtcNow
        };

        foreach (var item in dto.Items)
        {
            if (item.RequestedQuantity <= 0)
                throw new ValidationException(
                    "Requested quantity must be greater than zero.");

            request.Items.Add(new ReplenishmentItem
            {
                ArticleNumber = item.ArticleNumber.Trim(),
                Description = item.Description.Trim(),
                RequestedQuantity = item.RequestedQuantity
            });
        }

        _db.ReplenishmentRequests.Add(request);

        await _db.SaveChangesAsync();

        return ToDetailDto(request);
    }

    public async Task<PagedResult<RequestSummaryDto>> GetAsync(
        string? status,
        string? priority,
        string? location,
        int page,
        int pageSize)
    {
        page = Math.Max(page, 1);
        pageSize = Math.Clamp(pageSize, 1, 50);

        var query = _db.ReplenishmentRequests
            .AsNoTracking()
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(status))
        {
            if (Enum.TryParse<RequestStatus>(
                status,
                true,
                out var statusValue))
            {
                query = query.Where(x => x.Status == statusValue);
            }
        }

        if (!string.IsNullOrWhiteSpace(priority))
        {
            if (Enum.TryParse<RequestPriority>(
                priority,
                true,
                out var priorityValue))
            {
                query = query.Where(x => x.Priority == priorityValue);
            }
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            query = query.Where(x =>
                x.StockLocation.Contains(location));
        }

        var total = await query.CountAsync();

        var requests = await query
            .OrderByDescending(x => x.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new RequestSummaryDto
            {
                Id = x.Id,
                StockLocation = x.StockLocation,
                Priority = x.Priority,
                Status = x.Status,
                ValidationStatus = x.ValidationStatus,
                ValidationMessage = x.ValidationMessage,
                ItemCount = x.Items.Count,
                CreatedAt = x.CreatedAt
            })
            .ToListAsync();

        return new PagedResult<RequestSummaryDto>
        {
            Items = requests,
            TotalCount = total,
            Page = page,
            PageSize = pageSize
        };
    }

    public async Task<RequestDetailDto?> GetByIdAsync(int id)
    {
        var request = await _db.ReplenishmentRequests
            .AsNoTracking()
            .Include(x => x.Items)
            .FirstOrDefaultAsync(x => x.Id == id);

        return request == null
            ? null
            : ToDetailDto(request);
    }

    public async Task SubmitAsync(int id)
    {
        var request = await _db.ReplenishmentRequests
            .FirstOrDefaultAsync(x => x.Id == id);

        if (request == null)
            throw new KeyNotFoundException();

        if (request.Status != RequestStatus.Draft)
            throw new InvalidOperationException(
                "Only Draft requests can be submitted.");

        request.Status = RequestStatus.Submitted;
        request.SubmittedAt = DateTime.UtcNow;
        request.ValidationStatus = ValidationStatus.Pending;
        request.ValidationMessage =
            "Stock validation is in progress.";

        await _db.SaveChangesAsync();

        // Important: don't wait for slow stock service here
        await _queue.EnqueueAsync(id);
    }

    public async Task ApproveAsync(int id)
    {
        var request = await _db.ReplenishmentRequests
            .FirstOrDefaultAsync(x => x.Id == id);

        if (request == null)
            throw new KeyNotFoundException();

        if (request.Status != RequestStatus.Submitted)
            throw new InvalidOperationException(
                "Only Submitted requests can be approved.");

        if (request.ValidationStatus != ValidationStatus.Available)
            throw new InvalidOperationException(
                "Request cannot be approved until stock validation succeeds.");

        request.Status = RequestStatus.Approved;

        await _db.SaveChangesAsync();
    }

    public async Task RejectAsync(
        int id,
        string reason)
    {
        if (string.IsNullOrWhiteSpace(reason))
            throw new ValidationException(
                "Rejection reason is required.");

        var request = await _db.ReplenishmentRequests
            .FirstOrDefaultAsync(x => x.Id == id);

        if (request == null)
            throw new KeyNotFoundException();

        if (request.Status != RequestStatus.Submitted)
            throw new InvalidOperationException(
                "Only Submitted requests can be rejected.");

        request.Status = RequestStatus.Rejected;
        request.RejectionReason = reason.Trim();

        await _db.SaveChangesAsync();
    }

    public async Task FulfillAsync(
        int id,
        FulfillRequestDto dto)
    {
        var request = await _db.ReplenishmentRequests
            .Include(x => x.Items)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (request == null)
            throw new KeyNotFoundException();

        if (request.Status != RequestStatus.Approved)
            throw new InvalidOperationException(
                "Only Approved requests can be fulfilled.");

        foreach (var item in request.Items)
        {
            var fulfilled =
                dto.Items.FirstOrDefault(x =>
                    x.ItemId == item.Id);

            if (fulfilled == null)
                throw new ValidationException(
                    "Fulfilled quantity is required for every item.");

            if (fulfilled.FulfilledQuantity < 0 ||
                fulfilled.FulfilledQuantity >
                item.RequestedQuantity)
            {
                throw new ValidationException(
                    "Fulfilled quantity cannot exceed requested quantity.");
            }

            item.FulfilledQuantity =
                fulfilled.FulfilledQuantity;
        }

        request.Status = RequestStatus.Fulfilled;
        request.FulfilledAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();
    }

    private static RequestDetailDto ToDetailDto(
        ReplenishmentRequest request)
    {
        return new RequestDetailDto
        {
            Id = request.Id,
            StockLocation = request.StockLocation,
            Priority = request.Priority,
            Status = request.Status,
            ValidationStatus = request.ValidationStatus,
            ValidationMessage = request.ValidationMessage,
            RejectionReason = request.RejectionReason,
            CreatedAt = request.CreatedAt,
            SubmittedAt = request.SubmittedAt,

            Items = request.Items
                .Select(x => new RequestItemDto
                {
                    Id = x.Id,
                    ArticleNumber = x.ArticleNumber,
                    Description = x.Description,
                    RequestedQuantity = x.RequestedQuantity,
                    FulfilledQuantity = x.FulfilledQuantity
                })
                .ToList()
        };
    }
}