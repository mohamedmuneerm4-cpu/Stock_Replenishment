﻿using System.Threading.Channels;

namespace StockReplenishment.Services;

public class ValidationQueue : IValidationQueue
{
    private readonly Channel<int> _queue;

    public ValidationQueue()
    {
        _queue = Channel.CreateUnbounded<int>();
    }

    public async ValueTask EnqueueAsync(int requestId)
    {
        await _queue.Writer.WriteAsync(requestId);
    }

    public async ValueTask<int> DequeueAsync(
        CancellationToken cancellationToken)
    {
        return await _queue.Reader.ReadAsync(cancellationToken);
    }
}