using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using StockReplenishment.Components;
using StockReplenishment.Data;
using StockReplenishment.Services;

var builder = WebApplication.CreateBuilder(args);

// Blazor
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Web API
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// EF Core In-Memory
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("StockReplenishmentDb"));

// MudBlazor
builder.Services.AddMudServices();

// Application services
builder.Services.AddScoped<ReplenishmentService>();

builder.Services.AddScoped<IStockAvailabilityService,
    StockAvailabilityService>();

// Background queue
builder.Services.AddSingleton<IValidationQueue,
    ValidationQueue>();

builder.Services.AddHostedService<StockValidationWorker>();

// ⭐ API Client used by Blazor UI
builder.Services.AddHttpClient<RequestApiClient>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5200/");
});

var app = builder.Build();

// Seed database
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider
        .GetRequiredService<AppDbContext>();

    await DbSeeder.SeedAsync(db);
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseAntiforgery();

// API
app.MapControllers();

// Blazor
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();