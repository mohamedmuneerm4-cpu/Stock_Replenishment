﻿using Microsoft.EntityFrameworkCore;
using StockReplenishment.Models;

namespace StockReplenishment.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(
        AppDbContext db)
    {
        if (await db.ReplenishmentRequests.AnyAsync())
            return;

        var requests = new List<ReplenishmentRequest>
        {
            new()
            {
                StockLocation = "LINE-01",
                Priority = RequestPriority.Urgent,
                Status = RequestStatus.Submitted,
                ValidationStatus = ValidationStatus.Available,
                ValidationMessage = "Stock is available.",
                CreatedAt = DateTime.UtcNow.AddMinutes(-30),
                SubmittedAt = DateTime.UtcNow.AddMinutes(-20),
                Items =
                [
                    new()
                    {
                        ArticleNumber = "MAT-1001",
                        Description = "Motor Assembly",
                        RequestedQuantity = 20
                    }
                ]
            },

            new()
            {
                StockLocation = "LINE-02",
                Priority = RequestPriority.Normal,
                Status = RequestStatus.Approved,
                ValidationStatus = ValidationStatus.Available,
                ValidationMessage = "Stock is available.",
                CreatedAt = DateTime.UtcNow.AddHours(-2),
                SubmittedAt = DateTime.UtcNow.AddHours(-1),
                Items =
                [
                    new()
                    {
                        ArticleNumber = "MAT-2001",
                        Description = "Bearing",
                        RequestedQuantity = 30
                    }
                ]
            },

            new()
            {
                StockLocation = "WAREHOUSE-A",
                Priority = RequestPriority.Low,
                Status = RequestStatus.Draft,
                ValidationStatus = ValidationStatus.NotStarted,
                CreatedAt = DateTime.UtcNow.AddHours(-3),
                Items =
                [
                    new()
                    {
                        ArticleNumber = "MAT-3001",
                        Description = "Steel Plate",
                        RequestedQuantity = 10
                    }
                ]
            },

            new()
            {
                StockLocation = "LINE-03",
                Priority = RequestPriority.Normal,
                Status = RequestStatus.Rejected,
                ValidationStatus = ValidationStatus.Available,
                ValidationMessage = "Stock is available.",
                RejectionReason = "Duplicate request.",
                CreatedAt = DateTime.UtcNow.AddDays(-1),
                Items =
                [
                    new()
                    {
                        ArticleNumber = "MAT-4001",
                        Description = "Plastic Cover",
                        RequestedQuantity = 15
                    }
                ]
            }
        };

        db.ReplenishmentRequests.AddRange(requests);

        await db.SaveChangesAsync();
    }
}