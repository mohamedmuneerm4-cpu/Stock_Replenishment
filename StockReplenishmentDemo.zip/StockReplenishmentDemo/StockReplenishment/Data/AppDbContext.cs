﻿using Microsoft.EntityFrameworkCore;
using StockReplenishment.Models;

namespace StockReplenishment.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<ReplenishmentRequest> ReplenishmentRequests => Set<ReplenishmentRequest>();

    public DbSet<ReplenishmentItem> ReplenishmentItems => Set<ReplenishmentItem>();
}