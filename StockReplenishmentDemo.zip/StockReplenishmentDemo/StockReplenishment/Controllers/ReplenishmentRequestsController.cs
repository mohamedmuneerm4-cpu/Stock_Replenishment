﻿using Microsoft.AspNetCore.Mvc;
using StockReplenishment.DTOs;
using StockReplenishment.Services;
using System.ComponentModel.DataAnnotations;

namespace StockReplenishment.Controllers;

[ApiController]
[Route("api/replenishment-requests")]
public class ReplenishmentRequestsController : ControllerBase
{
    private readonly ReplenishmentService _service;

    public ReplenishmentRequestsController(
        ReplenishmentService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<RequestSummaryDto>>> Get(
        string? status,
        string? priority,
        string? location,
        int page = 1,
        int pageSize = 10)
    {
        var result = await _service.GetAsync(
            status,
            priority,
            location,
            page,
            pageSize);

        return Ok(result);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<RequestDetailDto>> GetById(
        int id)
    {
        var result = await _service.GetByIdAsync(id);

        if (result == null)
            return NotFound();

        return Ok(result);
    }

    [HttpPost]
    public async Task<ActionResult<RequestDetailDto>> Create(
        CreateRequestDto dto)
    {
        try
        {
            var result = await _service.CreateAsync(dto);

            return CreatedAtAction(
                nameof(GetById),
                new { id = result.Id },
                result);
        }
        catch (ValidationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("{id:int}/submit")]
    public async Task<IActionResult> Submit(int id)
    {
        try
        {
            await _service.SubmitAsync(id);

            return Accepted(new
            {
                message = "Request submitted. Stock validation started."
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
    }

    [HttpPost("{id:int}/approve")]
    public async Task<IActionResult> Approve(int id)
    {
        try
        {
            await _service.ApproveAsync(id);

            return Ok(new
            {
                message = "Request approved."
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
    }

    [HttpPost("{id:int}/reject")]
    public async Task<IActionResult> Reject(
        int id,
        RejectRequestDto dto)
    {
        try
        {
            await _service.RejectAsync(id, dto.Reason);

            return Ok(new
            {
                message = "Request rejected."
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
        catch (ValidationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("{id:int}/fulfill")]
    public async Task<IActionResult> Fulfill(
        int id,
        FulfillRequestDto dto)
    {
        try
        {
            await _service.FulfillAsync(id, dto);

            return Ok(new
            {
                message = "Request fulfilled."
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
        catch (ValidationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
}