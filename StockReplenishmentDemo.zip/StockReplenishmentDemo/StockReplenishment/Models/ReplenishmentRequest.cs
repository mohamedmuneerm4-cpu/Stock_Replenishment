﻿namespace StockReplenishment.Models;

public class ReplenishmentRequest
{
    public int Id { get; set; }

    public string StockLocation { get; set; } = string.Empty;

    public RequestPriority Priority { get; set; }

    public RequestStatus Status { get; set; } = RequestStatus.Draft;

    public ValidationStatus ValidationStatus { get; set; }
        = ValidationStatus.NotStarted;

    public string? ValidationMessage { get; set; }

    public string? RejectionReason { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime? SubmittedAt { get; set; }

    public DateTime? FulfilledAt { get; set; }

    public List<ReplenishmentItem> Items { get; set; } = [];
}