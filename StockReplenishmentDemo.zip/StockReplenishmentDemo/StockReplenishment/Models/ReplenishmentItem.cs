﻿namespace StockReplenishment.Models;

public class ReplenishmentItem
{
    public int Id { get; set; }

    public int ReplenishmentRequestId { get; set; }

    public string ArticleNumber { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public int RequestedQuantity { get; set; }

    public int FulfilledQuantity { get; set; }
}