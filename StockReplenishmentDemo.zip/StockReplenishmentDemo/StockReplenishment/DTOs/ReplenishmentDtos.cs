﻿using System.ComponentModel.DataAnnotations;
using StockReplenishment.Models;

namespace StockReplenishment.DTOs;

public class CreateRequestDto
{
    [Required]
    [MinLength(2)]
    public string StockLocation { get; set; } = string.Empty;

    public RequestPriority Priority { get; set; } = RequestPriority.Normal;

    [Required]
    [MinLength(1)]
    public List<CreateRequestItemDto> Items { get; set; } = [];
}

public class CreateRequestItemDto
{
    [Required]
    public string ArticleNumber { get; set; } = string.Empty;

    [Required]
    public string Description { get; set; } = string.Empty;

    [Range(1, 10000)]
    public int RequestedQuantity { get; set; }
}

public class RejectRequestDto
{
    [Required]
    [MinLength(3)]
    public string Reason { get; set; } = string.Empty;
}

public class FulfillRequestDto
{
    [Required]
    [MinLength(1)]
    public List<FulfillItemDto> Items { get; set; } = [];
}

public class FulfillItemDto
{
    public int ItemId { get; set; }

    [Range(0, 10000)]
    public int FulfilledQuantity { get; set; }
}

public class RequestSummaryDto
{
    public int Id { get; set; }
    public string StockLocation { get; set; } = string.Empty;
    public RequestPriority Priority { get; set; }
    public RequestStatus Status { get; set; }
    public ValidationStatus ValidationStatus { get; set; }
    public string? ValidationMessage { get; set; }
    public int ItemCount { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RequestDetailDto
{
    public int Id { get; set; }
    public string StockLocation { get; set; } = string.Empty;
    public RequestPriority Priority { get; set; }
    public RequestStatus Status { get; set; }
    public ValidationStatus ValidationStatus { get; set; }
    public string? ValidationMessage { get; set; }
    public string? RejectionReason { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? SubmittedAt { get; set; }

    public List<RequestItemDto> Items { get; set; } = [];
}

public class RequestItemDto
{
    public int Id { get; set; }
    public string ArticleNumber { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int RequestedQuantity { get; set; }
    public int FulfilledQuantity { get; set; }
}

public class PagedResult<T>
{
    public List<T> Items { get; set; } = [];
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }

    public int TotalPages =>
        (int)Math.Ceiling(TotalCount / (double)PageSize);
}