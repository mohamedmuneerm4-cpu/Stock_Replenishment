# Stock Replenishment Request System

## Overview

A small stock replenishment request system built using ASP.NET Core,
Blazor and MudBlazor.

## Tech Stack

- .NET 10
- ASP.NET Core Web API
- Entity Framework Core
- EF Core InMemory Database
- Blazor
- MudBlazor
- NUnit
- NSubstitute

## Workflow

Draft → Submitted → Approved → Fulfilled

Submitted → Rejected

When a request is submitted, stock availability is checked
asynchronously using a background worker.

## Architecture

Blazor UI
    ↓
REST API
    ↓
Service Layer
    ↓
EF Core InMemory

Submit
    ↓
Background Queue
    ↓
Stock Validation Worker
    ↓
Slow Stock Availability Service

## Run

```bash
dotnet restore
dotnet build
dotnet run